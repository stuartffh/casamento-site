import { createGlobalStyle } from 'styled-components';

const GlobalStyles = createGlobalStyle`
  :root {
    --cor-primaria-clara: #B695C0;
    --cor-primaria-escura: #503459;
    --cor-secundaria: #425943;
    --cor-branco: #FFFFFF;
    
    /* Cores adicionais para UI */
    --cor-fundo: #F9F6FA;
    --cor-texto: #333333;
    --cor-borda: #E0D5E6;
    --cor-erro: #D32F2F;
    --cor-sucesso: #388E3C;
  }

  * {
    margin: 0;
    padding: 0;
    box-sizing: border-box;
  }

  body {
    font-family: 'Montserrat', 'Helvetica Neue', sans-serif;
    background-color: var(--cor-fundo);
    color: var(--cor-texto);
    line-height: 1.6;
  }

  h1, h2, h3, h4, h5, h6 {
    font-family: 'Playfair Display', serif;
    color: var(--cor-primaria-escura);
    margin-bottom: 1rem;
  }

  p {
    margin-bottom: 1rem;
  }

  a {
    color: var(--cor-primaria-escura);
    text-decoration: none;
    transition: color 0.3s ease;
    
    &:hover {
      color: var(--cor-primaria-clara);
    }
  }

  button {
    cursor: pointer;
    font-family: 'Montserrat', sans-serif;
    font-weight: 500;
    border: none;
    border-radius: 4px;
    padding: 0.75rem 1.5rem;
    background-color: var(--cor-primaria-escura);
    color: var(--cor-branco);
    transition: background-color 0.3s ease;
    
    &:hover {
      background-color: var(--cor-primaria-clara);
    }
    
    &:disabled {
      background-color: var(--cor-borda);
      cursor: not-allowed;
    }
  }

  input, textarea, select {
    font-family: 'Montserrat', sans-serif;
    padding: 0.75rem;
    border: 1px solid var(--cor-borda);
    border-radius: 4px;
    width: 100%;
    margin-bottom: 1rem;
    
    &:focus {
      outline: none;
      border-color: var(--cor-primaria-clara);
    }
  }

  .container {
    width: 100%;
    max-width: 1200px;
    margin: 0 auto;
    padding: 0 1rem;
  }

  .section {
    padding: 4rem 0;
  }

  /* Responsividade */
  @media (max-width: 992px) {
    .container {
      max-width: 100%;
    }
    
    .section {
      padding: 3rem 0;
    }
  }

  @media (max-width: 576px) {
    .section {
      padding: 2rem 0;
    }
    
    h1 {
      font-size: 1.75rem;
    }
    
    h2 {
      font-size: 1.5rem;
    }
  }
`;

export default GlobalStyles;
