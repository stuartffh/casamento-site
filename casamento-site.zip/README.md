# Site de Lista de Presentes de Casamento - Marília & Iago

Este repositório contém o código-fonte completo do site de lista de presentes de casamento para Marília e Iago, desenvolvido conforme as especificações solicitadas.

## Estrutura do Projeto

O projeto está organizado como um monorepo usando PNPM workspaces, com a seguinte estrutura:

```
casamento-site/
├── pnpm-workspace.yaml
├── apps/
│   ├── client/         # Frontend (React + Vite)
│   └── server/         # Backend (Node.js + Express)
└── database.sqlite     # Banco de dados SQLite
```

## Tecnologias Utilizadas

### Frontend
- React + Vite
- Styled Components
- React Router DOM
- Axios
- Context API para carrinho de presentes

### Backend
- Node.js 18 + Express
- Prisma ORM com SQLite
- JWT para autenticação
- Integração com Mercado Pago (Checkout Pro)
- Suporte a PIX

## Funcionalidades

### Páginas Públicas
- **Home**: Apresentação do casal, contagem regressiva até a data do casamento
- **Nossa História**: História do casal com fotos
- **Lista de Presentes**: Presentes disponíveis para compra online, lista física e opção de PIX
- **Confirme sua Presença**: Formulário RSVP para confirmação de presença
- **Informações**: Detalhes sobre cerimônia, recepção, dress code, hospedagem e transporte
- **Álbum**: Galerias de fotos organizadas por categoria

### Painel Administrativo
- **Login**: Autenticação segura com JWT
- **Dashboard**: Visão geral das estatísticas (RSVPs, presentes, etc.)
- **Configurações**: Gerenciamento de chave PIX e token do Mercado Pago
- **Presentes**: CRUD completo para gerenciamento de presentes
- **Conteúdo**: Edição de textos das páginas
- **Álbum**: Upload e organização de fotos
- **RSVPs**: Visualização e exportação de confirmações de presença

## Requisitos

- Node.js 18 ou superior
- PNPM 8 ou superior
- SQLite 3

## Instalação e Execução

### Configuração Inicial

1. Clone o repositório:
```bash
git clone https://github.com/seu-usuario/casamento-site.git
cd casamento-site
```

2. Instale as dependências:
```bash
pnpm install
```

### Backend

1. Configure as variáveis de ambiente:
```bash
cd apps/server
cp .env.example .env
```

2. Edite o arquivo `.env` com suas configurações:
```
DATABASE_URL="file:../../../database.sqlite"
JWT_SECRET="seu-segredo-jwt"
PORT=3001
```

3. Execute as migrações do banco de dados:
```bash
npx prisma migrate dev
```

4. Popule o banco de dados com dados iniciais:
```bash
npx prisma db seed
```

5. Inicie o servidor:
```bash
pnpm dev
```

O servidor estará disponível em `http://localhost:3001`.

### Frontend

1. Configure as variáveis de ambiente:
```bash
cd apps/client
cp .env.example .env
```

2. Edite o arquivo `.env` com suas configurações:
```
VITE_API_URL=http://localhost:3001
```

3. Inicie o cliente:
```bash
pnpm dev
```

O cliente estará disponível em `http://localhost:5173`.

## Acesso ao Painel Administrativo

- URL: `http://localhost:5173/admin`
- Email: `admin@casamento.com`
- Senha: `admin123`

## Endpoints da API

### Autenticação
- `POST /api/auth/login` - Autenticar administrador

### Configurações
- `GET /api/config` - Obter configurações
- `PUT /api/config` - Atualizar configurações

### Presentes
- `GET /api/presentes` - Listar todos os presentes
- `GET /api/presentes/:id` - Obter um presente específico
- `POST /api/presentes` - Criar um novo presente (protegido)
- `PUT /api/presentes/:id` - Atualizar um presente (protegido)
- `DELETE /api/presentes/:id` - Excluir um presente (protegido)

### RSVP
- `GET /api/rsvp` - Listar todas as confirmações (protegido)
- `POST /api/rsvp` - Registrar nova confirmação
- `GET /api/rsvp/export` - Exportar confirmações para CSV (protegido)

### Mercado Pago
- `POST /api/mercadopago/webhook` - Receber notificações de pagamento
- `POST /api/mercadopago/create-payment` - Criar pagamento

### Álbum
- `GET /api/album` - Obter todas as galerias
- `GET /api/album/:gallery` - Obter fotos de uma galeria específica
- `POST /api/album` - Adicionar nova foto (protegido)
- `PUT /api/album/reorder` - Reordenar fotos (protegido)
- `DELETE /api/album/:id` - Excluir foto (protegido)

### Conteúdo
- `GET /api/content/:section` - Obter conteúdo de uma seção
- `PUT /api/content/:section` - Atualizar conteúdo de uma seção (protegido)

## Deploy

### Frontend (Vercel)

1. Configure o projeto no Vercel:
```bash
cd apps/client
vercel
```

2. Para produção:
```bash
vercel --prod
```

### Backend (Render.com)

1. Crie um novo Web Service no Render.com
2. Configure o build command: `cd apps/server && npm install && npx prisma generate`
3. Configure o start command: `cd apps/server && npm start`
4. Adicione as variáveis de ambiente necessárias

## Extras Implementados

- Exportação de RSVP em CSV
- Web-hooks para atualização de status de presentes
- Otimização Lighthouse (Performance, SEO)
- Responsividade completa (desktop, tablet, mobile)

## Licença

Este projeto está licenciado sob a licença MIT - veja o arquivo LICENSE para detalhes.
